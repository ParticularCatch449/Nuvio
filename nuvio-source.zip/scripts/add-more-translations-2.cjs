const fs = require('fs');

const path = 'src/data/translations.ts';
let code = fs.readFileSync(path, 'utf8');

const baseStrings = [
  "Welcome",
  "Performance",
  "Visuals",
  "Language",
  "API Keys",
  "Collections",
  "Export",
  "API Integrations",
  "Set up API keys later in AIO Meta Data",
  "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta."
];

const mockTranslations = {
  'zh-CN': {
    "Welcome": "欢迎",
    "Performance": "性能",
    "Visuals": "视觉",
    "Language": "语言",
    "API Keys": "API 密钥",
    "Collections": "集合",
    "Export": "导出",
    "API Integrations": "API 集成",
    "Set up API keys later in AIO Meta Data": "稍后在 AIO Meta Data 中设置 API 密钥",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "我理解在配置所需的 API 密钥之前，集成将不起作用。我选择稍后在 AIO Meta 中进行配置。"
  },
  'ar-SA': {
    "Welcome": "مرحباً",
    "Performance": "الأداء",
    "Visuals": "المرئيات",
    "Language": "اللغة",
    "API Keys": "مفاتيح API",
    "Collections": "المجموعات",
    "Export": "تصدير",
    "API Integrations": "تكاملات API",
    "Set up API keys later in AIO Meta Data": "إعداد مفاتيح API لاحقًا في بيانات AIO Meta",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "أدرك أن التكامل لن يعمل حتى يتم تكوين مفاتيح API المطلوبة. أختار تكوينها لاحقًا داخل AIO Meta."
  },
  'es-ES': {
    "Welcome": "Bienvenido",
    "Performance": "Rendimiento",
    "Visuals": "Visuales",
    "Language": "Idioma",
    "API Keys": "Claves API",
    "Collections": "Colecciones",
    "Export": "Exportar",
    "API Integrations": "Integraciones API",
    "Set up API keys later in AIO Meta Data": "Configurar claves API más tarde en AIO Meta Data",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "Entiendo que la integración no funcionará hasta que se configuren las claves API requeridas. Elijo configurarlas más tarde en AIO Meta."
  },
  'fr-FR': {
    "Welcome": "Bienvenue",
    "Performance": "Performances",
    "Visuals": "Visuels",
    "Language": "Langue",
    "API Keys": "Clés API",
    "Collections": "Collections",
    "Export": "Exporter",
    "API Integrations": "Intégrations API",
    "Set up API keys later in AIO Meta Data": "Configurer les clés API plus tard dans AIO Meta Data",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "Je comprends que l'intégration ne fonctionnera pas tant que les clés API requises ne seront pas configurées. Je choisis de les configurer plus tard dans AIO Meta."
  },
  'de-DE': {
    "Welcome": "Willkommen",
    "Performance": "Leistung",
    "Visuals": "Optik",
    "Language": "Sprache",
    "API Keys": "API-Schlüssel",
    "Collections": "Sammlungen",
    "Export": "Export",
    "API Integrations": "API-Integrationen",
    "Set up API keys later in AIO Meta Data": "API-Schlüssel später in AIO Meta Data einrichten",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "Ich verstehe, dass die Integration nicht funktioniert, bis die erforderlichen API-Schlüssel konfiguriert sind. Ich wähle aus, sie später in AIO Meta zu konfigurieren."
  },
  'it-IT': {
    "Welcome": "Benvenuto",
    "Performance": "Prestazioni",
    "Visuals": "Grafica",
    "Language": "Lingua",
    "API Keys": "Chiavi API",
    "Collections": "Collezioni",
    "Export": "Esporta",
    "API Integrations": "Integrazioni API",
    "Set up API keys later in AIO Meta Data": "Imposta le chiavi API in un secondo momento in AIO Meta Data",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "Comprendo che l'integrazione non funzionerà finché non saranno configurate le chiavi API richieste. Scelgo di configurarle in un secondo momento in AIO Meta."
  },
  'pt-BR': {
    "Welcome": "Bem-vindo",
    "Performance": "Desempenho",
    "Visuals": "Visuais",
    "Language": "Idioma",
    "API Keys": "Chaves API",
    "Collections": "Coleções",
    "Export": "Exportar",
    "API Integrations": "Integrações API",
    "Set up API keys later in AIO Meta Data": "Configurar chaves API mais tarde no AIO Meta Data",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "Entendo que a integração não funcionará até que as chaves API necessárias sejam configuradas. Escolho configurá-las mais tarde no AIO Meta."
  },
  'hi-IN': {
    "Welcome": "स्वागत",
    "Performance": "प्रदर्शन",
    "Visuals": "दृश्य",
    "Language": "भाषा",
    "API Keys": "API कुंजियाँ",
    "Collections": "संग्रह",
    "Export": "निर्यात",
    "API Integrations": "API एकीकरण",
    "Set up API keys later in AIO Meta Data": "AIO मेटा डेटा में बाद में API कुंजियाँ सेट करें",
    "I understand that the integration will not work until the required API keys (TMDB, TVDB, MDBList) are configured. I choose to configure them later within AIO Meta.": "मैं समझता हूँ कि जब तक आवश्यक API कुंजियाँ कॉन्फ़िगर नहीं की जातीं, तब तक एकीकरण काम नहीं करेगा। मैं उन्हें बाद में AIO मेटा में कॉन्फ़िगर करना चुनता हूँ।"
  }
};

for (const [lang, dict] of Object.entries(mockTranslations)) {
  const codeRegex = new RegExp(`('${lang}': \\{[\\s\\S]*?\\},)`);
  const match = code.match(codeRegex);
  if (match) {
    let existingDictStr = match[1];
    let existingDict = {};
    eval(`existingDict = {${existingDictStr.slice(0, -1)}};`);
    Object.assign(existingDict[lang], dict);
    const replacementStr = `'${lang}': ` + JSON.stringify(existingDict[lang], null, 4).replace(/\n/g, '\n  ') + ',';
    code = code.replace(codeRegex, replacementStr);
  }
}

fs.writeFileSync(path, code);
console.log('Language patch 2 OK');
