const https = require('https');

function getHTML(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

function extractId(data) {
  // It might be in some inline script
  const match1 = data.match(/list\/(\d+)/);
  if (match1) return match1[1];
  const match2 = data.match(/api\.mdblist\.com\/lists\/(\d+)/);
  if (match2) return match2[1];
  const match3 = data.match(/data-listid="(\d+)"/);
  if (match3) return match3[1];
  
  // also try to find the ID somewhere around "id" with a big number
  const match4 = data.match(/"id":\s*(\d{4,7})/);
  if (match4) return match4[1];

  return null;
}

const urls = [
  'https://mdblist.com/lists/atb001/marvel-cinematic-universe-movies-only',
  'https://mdblist.com/lists/lt3dave/marvel-cinematic-universe-mcu-shows-in-order',
  'https://mdblist.com/lists/chandu6889/dc-movies',
  'https://mdblist.com/lists/streamm1/dc-series',
  'https://mdblist.com/lists/jstinchcombe8642/universal-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/paramount-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/warner-bros-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/columbia-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/20th-century-studios-movies',
  'https://mdblist.com/lists/jstinchcombe8642/new-line-cinema-movies',
  'https://mdblist.com/lists/jstinchcombe8642/tristar-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/legendary-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/lionsgate-movies',
  'https://mdblist.com/lists/jstinchcombe8642/metro-goldwyn-mayer-movies',
  'https://mdblist.com/lists/jstinchcombe8642/dreamworks-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/amblin-entertainment-movies',
  'https://mdblist.com/lists/jstinchcombe8642/searchlight-pictures-movies',
  'https://mdblist.com/lists/jstinchcombe8642/a24-movies',
  'https://mdblist.com/lists/jstinchcombe8642/blumhouse-movies',
  'https://mdblist.com/lists/jstinchcombe8642/warner-bros-television-studios-series',
  'https://mdblist.com/lists/jstinchcombe8642/universal-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/sony-pictures-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/20th-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/paramount-television-studios-series',
  'https://mdblist.com/lists/jstinchcombe8642/cbs-studios-series',
  'https://mdblist.com/lists/jstinchcombe8642/lionsgate-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/mgm-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/abc-signature-series',
  'https://mdblist.com/lists/jstinchcombe8642/fx-productions-series',
  'https://mdblist.com/lists/jstinchcombe8642/nbcuniversal-content-studios-series',
  'https://mdblist.com/lists/jstinchcombe8642/sony-pictures-television-studios-series',
  'https://mdblist.com/lists/jstinchcombe8642/fremantle-north-america-series',
  'https://mdblist.com/lists/jstinchcombe8642/skydance-television-series',
  'https://mdblist.com/lists/jstinchcombe8642/ae-studios-series'
];

async function main() {
  for (const url of urls) {
    try {
      const data = await getHTML(url);
      const id = extractId(data);
      console.log(url, '=>', id);
    } catch (e) {
      console.error(url, '=>', e.message);
    }
  }
}

main();
