const fs = require('fs');
const cp = require('child_process');

const path = 'src/data/translations.ts';
const t = fs.readFileSync(path, 'utf8');

let esDictTxt = t.match(/'es-ES': \{([\s\S]*?)\},/)[1];
let esDict = {};
eval(`esDict = {${esDictTxt}};`);

const files = cp.execSync('find src -name "*.tsx"').toString().trim().split('\n');
const keys = new Set();
for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  const matches = content.matchAll(/translateText\(['"](.*?)['"]/g);
  for (const match of matches) {
    keys.add(match[1]);
  }
}

const missing = [];
for (const k of keys) {
  if (!esDict[k]) {
    missing.push(k);
  }
}

console.log('Missing in es-ES:', missing);
