import fs from 'fs';

const aioMetaObj = JSON.parse(fs.readFileSync('src/data/aioMetaBase.json', 'utf8'));
const aioMeta = Array.isArray(aioMetaObj) ? aioMetaObj : aioMetaObj.config?.catalogs || aioMetaObj.catalogs || [];
const nuvioCols = JSON.parse(fs.readFileSync('src/data/nuvioCollections.json', 'utf8'));

const aioCatalogsMap = new Map();
aioMeta.forEach((c: any) => aioCatalogsMap.set(c.id, c));

const findAioCatalog = (catalogId: string) => {
  if (!catalogId) return null;
  if (aioCatalogsMap.has(catalogId)) return aioCatalogsMap.get(catalogId);
  
  // try removing _movie or _series suffix
  let clean = catalogId.replace(/_(movie|series)$/, '');
  if (aioCatalogsMap.has(clean)) return aioCatalogsMap.get(clean);

  return null;
};

const usedCatalogs = new Set();
nuvioCols.forEach((col: any) => {
  col.folders.forEach((f: any) => {
    (f.catalogSources || f.sources || []).forEach((src: any) => {
      const matched = findAioCatalog(src.catalogId);
      if (matched) {
        usedCatalogs.add(matched.id);
      }
    });
  });
});

const unusedCatalogs = aioMeta.filter((c: any) => !usedCatalogs.has(c.id));

console.log("Unused length:", unusedCatalogs.length);
console.log(unusedCatalogs.map((c: any) => c.name));
