const fs = require('fs');
const collections = JSON.parse(fs.readFileSync('./src/data/nuvioCollections.json', 'utf8'));

// Find Franchises collection
let franchises = collections.find(c => c.title === 'Franchises');

if (franchises) {
  franchises.folders.forEach(f => {
    if (f.title === 'Marvel' || f.title === 'DC') {
      delete f.titleLogoUrl;
      delete f.coverImageUrl;
      delete f.heroBackdropUrl;
    }
  });
}

fs.writeFileSync('./src/data/nuvioCollections.json', JSON.stringify(collections, null, 2));

console.log('Done cleaning!');

