const fs = require('fs');

const aioMetaPath = './src/data/aioMetaBase.json';
const aioMeta = JSON.parse(fs.readFileSync(aioMetaPath, 'utf8'));

const mdblists = [
  { id: '200001', type: 'movie', name: 'Chinese Movies' },
  { id: '200002', type: 'series', name: 'Chinese Series' },
  { id: '200003', type: 'movie', name: 'Arabic Movies' },
  { id: '200004', type: 'series', name: 'Arabic Series' }
];

mdblists.forEach(item => {
  const catId = `mdblist.${item.id}`;
  if (!aioMeta.config.catalogs.find(c => c.id === catId)) {
    aioMeta.config.catalogs.push({
      id: catId,
      type: item.type,
      name: item.name,
      enabled: true,
      showInHome: false,
      source: "mdblist",
      sort: "default",
      order: "asc",
      cacheTTL: 86400,
      genreSelection: "standard",
      enableRatingPosters: true,
      displayType: item.name,
      metadata: {
        itemCount: 200,
        url: `https://mdblist.com/lists/dummy/${item.name.replace(/ /g, '-').toLowerCase()}`,
        mediatype: item.type
      }
    });
  }
});

fs.writeFileSync(aioMetaPath, JSON.stringify(aioMeta, null, 2));

const nuvioColsPath = './src/data/nuvioCollections.json';
const nuvioCols = JSON.parse(fs.readFileSync(nuvioColsPath, 'utf8'));

const intlCinema = nuvioCols.find(c => c.title === 'International Cinema');

if (intlCinema) {
  const cIndex = intlCinema.folders.findIndex(f => f.title === 'India');
  
  const chineseFolder = {
    "id": "folder-chinese-001",
    "title": "Chinese",
    "sources": [
      {
        "type": "Chinese Movies",
        "addonId": "aio-metadata",
        "provider": "addon",
        "catalogId": "mdblist.200001"
      },
      {
        "type": "Chinese Series",
        "addonId": "aio-metadata",
        "provider": "addon",
        "catalogId": "mdblist.200002"
      }
    ],
    "hideTitle": true,
    "tileShape": "LANDSCAPE",
    "catalogSources": [
      {
        "type": "Chinese Movies",
        "addonId": "aio-metadata",
        "catalogId": "mdblist.200001"
      },
      {
        "type": "Chinese Series",
        "addonId": "aio-metadata",
        "catalogId": "mdblist.200002"
      }
    ],
    "focusGifEnabled": false
  };

  const arabicFolder = {
    "id": "folder-arabic-001",
    "title": "Arabic",
    "sources": [
      {
        "type": "Arabic Movies",
        "addonId": "aio-metadata",
        "provider": "addon",
        "catalogId": "mdblist.200003"
      },
      {
        "type": "Arabic Series",
        "addonId": "aio-metadata",
        "provider": "addon",
        "catalogId": "mdblist.200004"
      }
    ],
    "hideTitle": true,
    "tileShape": "LANDSCAPE",
    "catalogSources": [
      {
        "type": "Arabic Movies",
        "addonId": "aio-metadata",
        "catalogId": "mdblist.200003"
      },
      {
        "type": "Arabic Series",
        "addonId": "aio-metadata",
        "catalogId": "mdblist.200004"
      }
    ],
    "focusGifEnabled": false
  };

  let hasChinese = intlCinema.folders.some(f => f.title === 'Chinese');
  let hasArabic = intlCinema.folders.some(f => f.title === 'Arabic');
  
  if (!hasChinese) {
    intlCinema.folders.splice(cIndex+1, 0, chineseFolder);
  }
  if (!hasArabic) {
    intlCinema.folders.splice(cIndex+2, 0, arabicFolder);
  }
}

fs.writeFileSync(nuvioColsPath, JSON.stringify(nuvioCols, null, 2));
console.log('Added to Nuvio and AioMeta successfully!');
