const fs = require('fs');
const path = 'src/data/translations.ts';
let code = fs.readFileSync(path, 'utf8');

const patches = {
  'es-ES': {
    "General": "General",
    "Show on Discover Page": "Mostrar en la página Descubrir",
    "Turn this off to only show the collection on the home page.": "Desactiva esto para mostrar la colección solo en la página principal.",
    "Just like configuring the Integrations tab in AIO Meta, these API keys are essential. If you don": "Al igual que al configurar la pestaña Integraciones en AIO Meta, estas claves de API son esenciales. Si no ",
    "Enter your {{key}} key": "Ingresa tu clave {{key}}",
    "You": "Tú",
    "Metadata Configuration": "Configuración de metadatos",
    "Nuvio Collections": "Colecciones Nuvio",
    "Use the download buttons above to get your custom configuration files.": "Utiliza los botones de descarga anteriores para obtener tus archivos de configuración.",
    ", create a password, and copy the addon link to install into the": ", crea una contraseña y copia el enlace del addon para instalarlo en el"
  },
  'fr-FR': {
    "General": "Général",
    "Show on Discover Page": "Afficher sur la page Découvrir",
    "Turn this off to only show the collection on the home page.": "Désactivez cette option pour n'afficher la collection que sur la page d'accueil.",
    "Just like configuring the Integrations tab in AIO Meta, these API keys are essential. If you don": "Tout comme la configuration de l'onglet Intégrations dans AIO Meta, ces clés d'API sont essentielles. Si vous ne",
    "Enter your {{key}} key": "Entrez votre clé {{key}}",
    "You": "Vous",
    "Metadata Configuration": "Configuration des métadonnées",
    "Nuvio Collections": "Collections Nuvio",
    "Use the download buttons above to get your custom configuration files.": "Utilisez les boutons de téléchargement ci-dessus pour obtenir vos fichiers de configuration.",
    ", create a password, and copy the addon link to install into the": ", créez un mot de passe et copiez le lien de l'addon pour l'installer dans le"
  },
  'de-DE': {
    "General": "Allgemein",
    "Show on Discover Page": "Auf Entdecken-Seite anzeigen",
    "Turn this off to only show the collection on the home page.": "Deaktivieren Sie diese Option, um die Sammlung nur auf der Startseite anzuzeigen.",
    "Just like configuring the Integrations tab in AIO Meta, these API keys are essential. If you don": "Wie bei der Konfiguration der Registerkarte „Integrationen“ in AIO Meta sind diese API-Schlüssel unverzichtbar.",
    "Enter your {{key}} key": "Geben Sie Ihren {{key}}-Schlüssel ein",
    "You": "Sie",
    "Metadata Configuration": "Metadaten-Konfiguration",
    "Nuvio Collections": "Nuvio-Sammlungen",
    "Use the download buttons above to get your custom configuration files.": "Verwenden Sie die Download-Schaltflächen oben, um Ihre benutzerdefinierten Konfigurationsdateien zu erhalten.",
    ", create a password, and copy the addon link to install into the": ", erstellen Sie ein Passwort und kopieren Sie den Addon-Link, um es im"
  },
  'it-IT': {
    "General": "Generale",
    "Show on Discover Page": "Mostra nella pagina Scopri",
    "Turn this off to only show the collection on the home page.": "Disattiva per mostrare la collezione solo nella home page.",
    "Just like configuring the Integrations tab in AIO Meta, these API keys are essential. If you don": "Proprio come la configurazione della scheda Integrazioni in AIO Meta, queste chiavi API sono essenziali. Se non",
    "Enter your {{key}} key": "Inserisci la tua chiave {{key}}",
    "You": "Tu",
    "Metadata Configuration": "Configurazione metadati",
    "Nuvio Collections": "Collezioni Nuvio",
    "Use the download buttons above to get your custom configuration files.": "Usa i pulsanti di download sopra per ottenere i file di configurazione.",
    ", create a password, and copy the addon link to install into the": ", crea una password e copia il link dell'addon per installarlo nel"
  }
};

for (const [lang, patch] of Object.entries(patches)) {
  let startIdx = code.indexOf(`'${lang}': {`);
  if (startIdx === -1) continue;
  let count = 0;
  let endIdx = startIdx;
  for (let i = startIdx + `'${lang}': `.length; i < code.length; i++) {
    if (code[i] === '{') count++;
    if (code[i] === '}') {
      count--;
      if (count === 0) {
        endIdx = i;
        break;
      }
    }
  }

  let dictStr = code.substring(startIdx, endIdx + 1);
  let existingDict = {};
  eval(`existingDict = {${dictStr}};`);

  Object.assign(existingDict[lang], patch);

  let newStr = `'${lang}': ` + JSON.stringify(existingDict[lang], null, 4).replace(/\n/g, '\n  ');
  code = code.substring(0, startIdx) + newStr + code.substring(endIdx + 1);
}

fs.writeFileSync(path, code);
console.log('Other languages patched.');
