const fs = require('fs');

const nuviFile = './src/data/nuvioCollections.json';
const aioFile = './src/data/aioMetaBase.json';

let nuvi = JSON.parse(fs.readFileSync(nuviFile, 'utf8'));
let aio = JSON.parse(fs.readFileSync(aioFile, 'utf8'));

// Update aioMetaBase
aio.config.catalogs.forEach(cat => {
    if (cat.id === 'mdblist.169305') {
        cat.name = 'Bad Robot Production';
        cat.displayType = 'Bad Robot Production';
    }
    if (cat.id === 'mdblist.169268') {
        cat.name = 'Sony Pictures - Movies';
        cat.displayType = 'Sony Pictures - Movies';
    }
});
fs.writeFileSync(aioFile, JSON.stringify(aio, null, 2));

// Update nuviCollections
nuvi.forEach(collection => {
    if (collection.title === 'Production Studios Movies') {
        collection.folders.forEach(folder => {
            if (folder.title === 'TriStar Pictures') {
                folder.title = 'Sony Pictures';
                folder.sources.forEach(s => s.type = 'Sony Pictures - Movies');
                folder.catalogSources.forEach(s => s.type = 'Sony Pictures - Movies');
            }
        });
        
        // Move Blumhouse to 4th (index 3)
        let blumhouseIdx = collection.folders.findIndex(f => f.title === 'Blumhouse');
        if (blumhouseIdx !== -1) {
            let blumhouse = collection.folders.splice(blumhouseIdx, 1)[0];
            collection.folders.splice(3, 0, blumhouse);
        }
    }
    
    if (collection.title === 'Production Studios Series') {
        collection.folders.forEach(folder => {
            if (folder.title === 'Sony Pictures Television Studios') {
                folder.title = 'Bad Robot Production';
                folder.sources.forEach(s => s.type = 'Bad Robot Production');
                folder.catalogSources.forEach(s => s.type = 'Bad Robot Production');
            }
        });
    }
});

fs.writeFileSync(nuviFile, JSON.stringify(nuvi, null, 2));
console.log('Modified names and moved Blumhouse.');
