const fs = require('fs');

const path = 'src/data/translations.ts';
let code = fs.readFileSync(path, 'utf8');

// 1. Add to SupportedLanguage
code = code.replace(
  "export type SupportedLanguage = 'en-US' | 'es-ES' | 'fr-FR' | 'de-DE' | 'it-IT' | 'pt-BR';",
  "export type SupportedLanguage = 'en-US' | 'es-ES' | 'fr-FR' | 'de-DE' | 'it-IT' | 'pt-BR' | 'zh-CN' | 'ar-SA' | 'hi-IN';"
);

// 2. Add to LANGUAGES
const newLangs = `  { code: 'pt-BR', label: 'Portuguese' },
  { code: 'zh-CN', label: 'Chinese' },
  { code: 'ar-SA', label: 'Arabic' },
  { code: 'hi-IN', label: 'Hindi' },`;
code = code.replace("  { code: 'pt-BR', label: 'Portuguese' },", newLangs);

// 3. Add empty dictionaries or somewhat populated dictionaries to TRANSLATIONS
// We can just add empty ones for now and let English take over for missing, 
// but wait, the prompt says "Ensure it updates the builder language, titles etc".
// Let's add them with empty objects first and then populate using a script.
const transMatch = code.match(/export const TRANSLATIONS: Record<SupportedLanguage, Record<string, string>> = \{/);
if (transMatch) {
  code = code.replace(
    /export const TRANSLATIONS: Record<SupportedLanguage, Record<string, string>> = \{/,
    `export const TRANSLATIONS: Record<SupportedLanguage, Record<string, string>> = {\n  'zh-CN': {},\n  'ar-SA': {},\n  'hi-IN': {},`
  );
}

fs.writeFileSync(path, code);
console.log('Added languages to translations.ts');
