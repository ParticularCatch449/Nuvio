const fs = require('fs');

const path = 'src/data/translations.ts';
let code = fs.readFileSync(path, 'utf8');

const ptBrPatch = {
  "General": "Geral",
  "Show on Discover Page": "Mostrar na página \"Descobrir\"",
  "Turn this off to only show the collection on the home page.": "Desative isso para mostrar a coleção apenas na página inicial.",
  "Debrid Providers": "Provedores Debrid",
  "Get API Key": "Obter Chave API",
  "Purchase Plan": "Comprar Plano",
  "API Key": "Chave API",
  "Visual Layout": "Layout Visual",
  "Label Style Preset": "Predefinição de Estilo de Rótulo",
  "Pick a predefined layout or build your own.": "Escolha um layout predefinido ou crie o seu próprio.",
  "Default": "Padrão",
  "Essential (Minimalista)": "Essencial (Minimalista)",
  "Complex (Detailed)": "Complexo (Detalhado)",
  "Pro (Clean & Formatted)": "Pro (Limpo e Formatado)",
  "Custom Format": "Formato Personalizado",
  "First Line (Name format)": "Primeira Linha (Formato do Nome)",
  "Second Line (Description format)": "Segunda Linha (Formato da Descrição)",
  "Live Preview (Mock Data)": "Visualização ao Vivo (Dados Falsos)",
  "Stream Rules": "Regras de Stream",
  "Fine-tune options related to Anime, Autoplay, language priorities, and quality caps.": "Ajuste opções relacionadas a Anime, Autoplay, prioridades de idioma e limites de qualidade.",
  "Enable Anime Enhancements": "Habilitar Melhorias de Anime",
  "Improves metadata extraction and streaming sources for anime.": "Melhora a extração de metadados e as fontes de streaming para anime.",
  "Anime Multi-Episode Autoplay Method": "Método de Autoplay para Múltiplos Episódios de Anime",
  "Match closest filename to requested episode (Recommended)": "Corresponder o nome de arquivo mais próximo ao episódio solicitado (Recomendado)",
  "Match by torrent sequence index": "Corresponder por índice de sequência do torrent",
  "Always pick the first file in torrent": "Sempre escolher o primeiro arquivo do torrent",
  "Priority Audio Languages": "Idiomas de Áudio Prioritários",
  "Pick preferred languages for Multi-Audio streams.": "Escolha os idiomas preferidos para streams de Multi-Áudio.",
  "Maximum Resolution Cap": "Limite Máximo de Resolução",
  "Only streams at or below this resolution will be returned.": "Apenas streams nesta resolução ou inferior serão retornados.",
  "Any Resolution (No Limit)": "Qualquer Resolução (Sem Limite)",
  "Limit to 4K / 2160p": "Limitar a 4K / 2160p",
  "Limit to Full HD / 1080p": "Limitar a Full HD / 1080p",
  "Limit to HD / 720p": "Limitar a HD / 720p",
  "Limit to SD / 480p": "Limitar a SD / 480p",
  "Exclude CAM / TS": "Excluir CAM / TS",
  "Filter out low-quality theater recordings.": "Filtrar gravações de cinema de baixa qualidade.",
  "Performance Limits": "Limites de Desempenho",
  "Enable Internet Speed Limit": "Habilitar Limite de Velocidade de Internet",
  "Filters out streams that are too large for your connection.": "Filtra streams que são muito grandes para a sua conexão.",
  "Download Speed (Mbps)": "Velocidade de Download (Mbps)",
  "Stream Sorting Preference": "Preferência de Classificação de Stream",
  "How would you like the streams to be ordered?": "Como você gostaria que os streams fossem ordenados?",
  "Quality First (Highest resolution at the top)": "Qualidade Primeiro (Maior resolução no topo)",
  "Speed First (Best cached sources first)": "Velocidade Primeiro (Melhores fontes cacheadas primeiro)",
  "Exclude Uncached Sources": "Excluir Fontes Não Cacheadas",
  "Only show streams already cached on your debrid provider.": "Mostrar apenas streams já cacheados no seu provedor de debrid.",
  "Just like configuring the Integrations tab in AIO Meta, these API keys are essential. If you don": "Assim como na configuração da guia Integrações no AIO Meta, essas chaves de API são essenciais.",
  "Enter your {{key}} key": "Insira sua chave {{key}}",
  "You": "Você",
  "Metadata Configuration": "Configuração de Metadados",
  "Nuvio Collections": "Coleções Nuvio",
  "Use the download buttons above to get your custom configuration files.": "Use os botões de download acima para obter seus arquivos de configuração personalizados.",
  ", create a password, and copy the addon link to install into the": ", crie uma senha e copie o link do addon para instalar no",
  "Welcome to Nuvio Account Builder": "Bem-vindo ao Criador de Contas Nuvio",
  "Configure your perfect Nuvio streaming experience. Choose whether you want to configure your streaming providers, curate your metadata catalogs and collections, or set up everything at once.": "Configure sua experiência perfeita de streaming no Nuvio. Escolha se deseja configurar seus provedores de streaming, curar seus catálogos de metadados e coleções, ou configurar tudo de uma vez.",
  "Streams Only": "Apenas Streams",
  "Configure your debrid providers (Real-Debrid, TorBox, etc.), performance limits, and stream sorting rules.": "Configure seus provedores de debrid, limites de desempenho e regras de classificação de streams.",
  "Collections Only": "Apenas Coleções",
  "Curate your catalogs, customize integrations (TMDB, Trakt), and select exactly which collections sync.": "Faça a curadoria de seus catálogos e selecione exatamente quais coleções sincronizar.",
  "Complete Builder": "Criador Completo",
  "The ultimate setup. Configure all stream rules and hand-pick your entire collection metadata in one pass.": "A configuração definitiva. Configure todas as regras de stream e selecione manualmente todos os metadados de sua coleção de uma só vez.",
  "Nuvio Account Builder": "Criador de Contas Nuvio",
  "Donate to the Dev": "Doe para o Desenvolvedor",
  "Configure how the streams addon resolves and sorts your content.": "Configure como as streams são resolvidas e ordenadas.",
  "Label Style Preset": "Estilo de Rótulo Predefinido",
  "Customize how stream titles and descriptions appear in Stremio.": "Personalize como os títulos e descrições dos streams aparecem no Stremio.",
  "Enable and configure the debrid providers you want to use for streaming. You must provide an API key for each enabled provider.": "Ative e configure os provedores de debrid que você deseja usar para streaming."
};

let ptStart = code.indexOf("'pt-BR': {");
let count = 0;
let ptEnd = ptStart;
for (let i = ptStart + "'pt-BR': ".length; i < code.length; i++) {
  if (code[i] === '{') count++;
  if (code[i] === '}') {
    count--;
    if (count === 0) {
      ptEnd = i;
      break;
    }
  }
}

let ptStr = code.substring(ptStart, ptEnd + 1);
let existingDict = {};
eval(`existingDict = {${ptStr}};`);

Object.assign(existingDict['pt-BR'], ptBrPatch);

let newStr = "'pt-BR': " + JSON.stringify(existingDict['pt-BR'], null, 4).replace(/\n/g, '\n  ');

code = code.substring(0, ptStart) + newStr + code.substring(ptEnd + 1);

fs.writeFileSync(path, code);
console.log('pt-BR patched.');
