const fs = require('fs');
const metaPath = './src/data/aioMetaBase.json';
const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));

const mdblists = [
  { url: 'https://mdblist.com/lists/atb001/marvel-cinematic-universe-movies-only', id: '9313', type: 'movie', name: 'Marvel Cinematic Universe Movies Only' },
  { url: 'https://mdblist.com/lists/lt3dave/marvel-cinematic-universe-mcu-shows-in-order', id: '32047', type: 'series', name: 'Marvel Cinematic Universe MCU Shows in Order' },
  { url: 'https://mdblist.com/lists/chandu6889/dc-movies', id: '98039', type: 'movie', name: 'DC Movies' },
  { url: 'https://mdblist.com/lists/streamm1/dc-series', id: '141051', type: 'series', name: 'DC Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/universal-pictures-movies', id: '169256', type: 'movie', name: 'Universal Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/paramount-pictures-movies', id: '169259', type: 'movie', name: 'Paramount Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/warner-bros-pictures-movies', id: '169261', type: 'movie', name: 'Warner Bros. Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/columbia-pictures-movies', id: '169263', type: 'movie', name: 'Columbia Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/20th-century-studios-movies', id: '169264', type: 'movie', name: '20th Century Studios - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/new-line-cinema-movies', id: '169267', type: 'movie', name: 'New Line Cinema - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/tristar-pictures-movies', id: '169268', type: 'movie', name: 'TriStar Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/legendary-pictures-movies', id: '169270', type: 'movie', name: 'Legendary Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/lionsgate-movies', id: '169273', type: 'movie', name: 'Lionsgate - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/metro-goldwyn-mayer-movies', id: '169274', type: 'movie', name: 'Metro-Goldwyn-Mayer - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/dreamworks-pictures-movies', id: '169275', type: 'movie', name: 'DreamWorks Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/amblin-entertainment-movies', id: '169277', type: 'movie', name: 'Amblin Entertainment - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/searchlight-pictures-movies', id: '169278', type: 'movie', name: 'Searchlight Pictures - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/a24-movies', id: '169281', type: 'movie', name: 'A24 - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/blumhouse-movies', id: '169315', type: 'movie', name: 'Blumhouse - Movies' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/warner-bros-television-studios-series', id: '169283', type: 'series', name: 'Warner Bros. Television Studios - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/universal-television-series', id: '169284', type: 'series', name: 'Universal Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/sony-pictures-television-series', id: '169286', type: 'series', name: 'Sony Pictures Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/20th-television-series', id: '169289', type: 'series', name: '20th Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/paramount-television-studios-series', id: '169290', type: 'series', name: 'Paramount Television Studios - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/cbs-studios-series', id: '169291', type: 'series', name: 'CBS Studios - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/lionsgate-television-series', id: '169293', type: 'series', name: 'Lionsgate Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/mgm-television-series', id: '169294', type: 'series', name: 'MGM Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/abc-signature-series', id: '169295', type: 'series', name: 'ABC Signature - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/fx-productions-series', id: '169297', type: 'series', name: 'FX Productions - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/nbcuniversal-content-studios-series', id: '169302', type: 'series', name: 'NBCUniversal Content Studios - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/sony-pictures-television-studios-series', id: '169305', type: 'series', name: 'Sony Pictures Television Studios - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/fremantle-north-america-series', id: '169308', type: 'series', name: 'Fremantle North America - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/skydance-television-series', id: '169311', type: 'series', name: 'Skydance Television - Series' },
  { url: 'https://mdblist.com/lists/jstinchcombe8642/ae-studios-series', id: '169314', type: 'series', name: 'A+E Studios - Series' }
];

let changed = false;

mdblists.forEach(item => {
  const catId = `mdblist.${item.id}`;
  if (!meta.config.catalogs.find(c => c.id === catId)) {
    meta.config.catalogs.push({
      id: catId,
      type: item.type,
      name: item.name,
      enabled: true,
      showInHome: false,
      source: "mdblist",
      sort: "default",
      order: "asc",
      cacheTTL: 86400,
      genreSelection: "standard",
      enableRatingPosters: true,
      displayType: item.name,
      metadata: {
        itemCount: 200,
        url: item.url,
        mediatype: item.type
      }
    });
    changed = true;
  }
});

if (changed) {
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));
  console.log('Added new catalogs to aioMetaBase.json');
} else {
  console.log('No new catalogs needed adding.');
}
