const fs = require('fs');

const path = 'src/data/translations.ts';
let code = fs.readFileSync(path, 'utf8');

const dictionaries = {
  'zh-CN': {
    "Welcome to Nuvio Account Builder": "欢迎使用 Nuvio 账户生成器",
    "Configure your perfect Nuvio streaming experience. Choose whether you want to configure your streaming providers, curate your metadata catalogs and collections, or set up everything at once.": "配置完美的 Nuvio 流媒体体验。选择是否配置流媒体提供商、整理元数据目录和集合，或一次性设置所有内容。",
    "Streams Only": "仅流媒体",
    "Configure your debrid providers (Real-Debrid, TorBox, etc.), performance limits, and stream sorting rules.": "配置您的 Debrid 提供商（Real-Debrid、TorBox 等）、性能限制和流排序规则。",
    "Collections Only": "仅集合",
    "Curate your catalogs, customize integrations (TMDB, Trakt), and select exactly which collections sync.": "整理您的目录，自定集成（TMDB、Trakt），并精确选择同步哪些集合。",
    "Complete Builder": "完整生成器",
    "The ultimate setup. Configure all stream rules and hand-pick your entire collection metadata in one pass.": "终极设置。一次性配置所有流媒体规则并手工挑选整个集合元数据。",
    "Nuvio Account Builder": "Nuvio 账户生成器",
    "Donate to the Dev": "向开发者捐赠",
    "Stream Rules": "流媒体规则",
    "Fine-tune options related to Anime, Autoplay, language priorities, and quality caps.": "微调与动漫、自动播放、语言优先级和质量限制相关的选项。",
    "Enable Anime Enhancements": "启用动漫增强功能",
    "Improves metadata extraction and streaming sources for anime.": "改进动漫的元数据提取和流媒体源。",
    "Anime Multi-Episode Autoplay Method": "动漫多集自动播放方法",
    "Match closest filename to requested episode (Recommended)": "将最接近的文件名与请求的剧集匹配（推荐）",
    "Match by torrent sequence index": "按种子序列索引匹配",
    "Always pick the first file in torrent": "始终选择种子中的第一个文件",
    "Priority Audio Languages": "优先音频语言",
    "Pick preferred languages for Multi-Audio streams.": "为多音频流选择首选语言。",
    "Maximum Resolution Cap": "最大分辨率上限",
    "Only streams at or below this resolution will be returned.": "将仅返回此分辨率或以下的流。",
    "Any Resolution (No Limit)": "任何分辨率（无限制）",
    "Limit to 4K / 2160p": "限制为 4K / 2160p",
    "Limit to Full HD / 1080p": "限制为全高清 / 1080p",
    "Limit to HD / 720p": "限制为高清 / 720p",
    "Limit to SD / 480p": "限制为标清 / 480p",
    "Exclude CAM / TS": "排除 CAM / TS",
    "Filter out low-quality theater recordings.": "过滤掉低质量的影院录像。",
    "Debrid Providers": "Debrid 提供商",
    "Enable and configure the debrid providers you want to use for streaming. You must provide an API key for each enabled provider.": "启用并配置您希望用于流媒体的 Debrid 提供商。您必须为每个启用的提供商提供 API 密钥。",
    "Get API Key": "获取 API 密钥",
    "Purchase Plan": "购买计划",
    "API Key": "API 密钥",
    "Enter API Key": "输入 API 密钥",
    "Performance Limits": "性能限制",
    "Configure how the streams addon resolves and sorts your content.": "配置流附加组件如何解析和排序您的内容。",
    "Enable Internet Speed Limit": "启用互联网速度限制",
    "Filters out streams that are too large for your connection.": "过滤掉对您的连接来说太大的流。",
    "Download Speed (Mbps)": "下载速度 (Mbps)",
    "Stream Sorting Preference": "流排序首选项",
    "How would you like the streams to be ordered?": "您希望如何订购这些流？",
    "Quality First (Highest resolution at the top)": "质量优先（最高分辨率在顶部）",
    "Speed First (Best cached sources first)": "速度优先（最佳缓存源在前）",
    "Exclude Uncached Sources": "排除未缓存来源",
    "Only show streams already cached on your debrid provider.": "仅显示您的 debrid 提供程序上已缓存的流。",
    "Visual Layout": "视觉布局",
    "Customize how stream titles and descriptions appear in Stremio.": "自定义流媒体标题和描述在 Stremio 中的显示方式。",
    "Label Style Preset": "标签样式预设",
    "Pick a predefined layout or build your own.": "选择预定义的布局或建立自己的布局。",
    "Default": "默认",
    "Essential (Minimalista)": "Essential (极简主义)",
    "Complex (Detailed)": "Complex (详细)",
    "Pro (Clean & Formatted)": "Pro (干净和格式化)",
    "Custom Format": "自定格式",
    "First Line (Name format)": "第一行 (名称格式)",
    "Second Line (Description format)": "第二行 (描述格式)",
    "Live Preview (Mock Data)": "实时预览 (模拟数据)"
  },
  'ar-SA': {
    "Welcome to Nuvio Account Builder": "مرحبًا بك في مُنشئ حساب Nuvio",
    "Configure your perfect Nuvio streaming experience. Choose whether you want to configure your streaming providers, curate your metadata catalogs and collections, or set up everything at once.": "قم بتكوين تجربة البث المثالية لـ Nuvio. اختر ما إذا كنت تريد تكوين مزودي البث أو تنظيم كتالوجات ومجموعات البيانات الوصفية أو إعداد كل شيء في وقت واحد.",
    "Streams Only": "التدفقات فقط",
    "Configure your debrid providers (Real-Debrid, TorBox, etc.), performance limits, and stream sorting rules.": "قم بتكوين مزودي الدبريد (Real-Debrid، TorBox، وما إلى ذلك)، وحدود الأداء، وقواعد فرز الدفق.",
    "Collections Only": "المجموعات فقط",
    "Curate your catalogs, customize integrations (TMDB, Trakt), and select exactly which collections sync.": "رعاية الكتالوجات وتخصيص عمليات الدمج (TMDB ، Trakt) وتحديد المجموعات التي تتزامن بدقة.",
    "Complete Builder": "مُنشئ كامل",
    "The ultimate setup. Configure all stream rules and hand-pick your entire collection metadata in one pass.": "الإعداد النهائي. قم بتكوين جميع قواعد الدفق واختر بيانات مجموعة البيانات الوصفية بالكامل دفعة واحدة.",
    "Nuvio Account Builder": "مُنشئ حساب Nuvio",
    "Donate to the Dev": "التبرع للمطور",
    "Stream Rules": "قواعد التدفق",
    "Fine-tune options related to Anime, Autoplay, language priorities, and quality caps.": "ضبط الخيارات المتعلقة بـ Anime والتشغيل التلقائي وأولويات اللغة وحدود الجودة.",
    "Enable Anime Enhancements": "تمكين تحسينات الأنمي",
    "Improves metadata extraction and streaming sources for anime.": "يحسن استخراج البيانات الوصفية ومصادر البث للأنمي.",
    "Anime Multi-Episode Autoplay Method": "طريقة التشغيل التلقائي لحلقات الأنمي المتعددة",
    "Match closest filename to requested episode (Recommended)": "تطابق أقرب اسم ملف مع الحلقة المطلوبة (موصى به)",
    "Match by torrent sequence index": "تطابق من خلال مؤشر تسلسل التورنت",
    "Always pick the first file in torrent": "اختر دائما أول ملف في التورنت",
    "Priority Audio Languages": "لغات الصوت ذات الأولوية",
    "Pick preferred languages for Multi-Audio streams.": "اختر اللغات المفضلة لدفقات الصوت المتعددة.",
    "Maximum Resolution Cap": "أقصى دقة",
    "Only streams at or below this resolution will be returned.": "سيتم إرجاع الدفقات فقط عند هذه الدقة أو أقل منها.",
    "Any Resolution (No Limit)": "أي دقة (بلا حدود)",
    "Limit to 4K / 2160p": "يقتصر على 4K / 2160p",
    "Limit to Full HD / 1080p": "يقتصر على Full HD / 1080p",
    "Limit to HD / 720p": "يقتصر على HD / 720p",
    "Limit to SD / 480p": "يقتصر على SD / 480p",
    "Exclude CAM / TS": "استبعاد CAM / TS",
    "Filter out low-quality theater recordings.": "تصفية تسجيلات المسرح منخفضة الجودة.",
    "Debrid Providers": "مزودو ديبريد",
    "Enable and configure the debrid providers you want to use for streaming. You must provide an API key for each enabled provider.": "قم بتمكين وتكوين مقدمي debrid الذين تريد استخدامهم للبث. يجب عليك تقديم مفتاح API لكل مزود ممكّن.",
    "Get API Key": "احصل على مفتاح API",
    "Purchase Plan": "خطة الشراء",
    "API Key": "مفتاح API",
    "Enter API Key": "أدخل مفتاح API",
    "Performance Limits": "حدود الأداء",
    "Configure how the streams addon resolves and sorts your content.": "تكوين كيفية فك شفرة محتوى دفق وفرزه.",
    "Enable Internet Speed Limit": "تمكين حد سرعة الإنترنت",
    "Filters out streams that are too large for your connection.": "دفق المرشحات التي تكون أطول من اتصالك.",
    "Download Speed (Mbps)": "سرعة التنزيل (Mbps)",
    "Stream Sorting Preference": "تفضيل فرز الدفق",
    "How would you like the streams to be ordered?": "كيف ترغب أن يتم طلب الدفقات؟",
    "Quality First (Highest resolution at the top)": "الجودة أولا (أعلى دقة في القمة)",
    "Speed First (Best cached sources first)": "السرعة أولا (أفضل مصادر في مخبأ)",
    "Exclude Uncached Sources": "استبعاد مصادر غير مخفية",
    "Only show streams already cached on your debrid provider.": "إظهار التدفقات المخبأة بالفعل على مزودك ديبريد.",
    "Visual Layout": "تخطيط مرئي",
    "Customize how stream titles and descriptions appear in Stremio.": "قم بتخصيص كيف تظهر عناوين الدفق والتوصيف في Stremio.",
    "Label Style Preset": "تسمية المجموعات المسبقة",
    "Pick a predefined layout or build your own.": "اختر تخطيط محدد مسبقا أو البناء.",
    "Default": "افتراضي",
    "Essential (Minimalista)": "أساسيات (الحد الأدنى)",
    "Complex (Detailed)": "معقدة (مفصل)",
    "Pro (Clean & Formatted)": "مؤيد (نظيف ومنسق)",
    "Custom Format": "تنسيق مخصص",
    "First Line (Name format)": "السطر الأول (تنسيق الاسم)",
    "Second Line (Description format)": "الخط الثاني (تنسيق الوصف)",
    "Live Preview (Mock Data)": "المعاينة الحقيقية (البيانات الخيالية)"
  }
};

for (const [lang, dict] of Object.entries(dictionaries)) {
  const codeRegex = new RegExp(`('${lang}': \\{[\\s\\S]*?\\},)`);
  const match = code.match(codeRegex);
  if (match) {
    let existingDictStr = match[1];
    
    let existingDict = {};
    eval(`existingDict = {${existingDictStr.slice(0, -1)}};`);
    
    // Merge new dict into existing dict
    Object.assign(existingDict[lang], dict);
    
    const replacementStr = `'${lang}': ` + JSON.stringify(existingDict[lang], null, 4).replace(/\n/g, '\n  ') + ',';
    code = code.replace(codeRegex, replacementStr);
  }
}

fs.writeFileSync(path, code);
